# This file is kept for backwards compatibility only.
# All package configuration is now in pyproject.toml
# Run: pip install -e . to install in development mode

from setuptools import setup

# Minimal setup.py for pip install -e . compatibility
setup()
